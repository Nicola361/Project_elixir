# UniversityKvStore

## Steps
  * mix setup
  * mix phx.server
  
## Steps using docker
  * docker compose up --build 
  * visit [`localhost:4000`](http://localhost:4000) from your browser

## Functionalities
  * added crud for student simple form
  * css using tailwind with built-in feature for phoenix liveview
  * data being stored in postgresql database
  * implement search by multiple fields from student table
  * crud reference: https://www.wbotelhos.com/crud-in-5-minutes-with-phoenix-and-elixir/
  * added docker release using mix phx.gen.release --docker
  * added faker library for running test cases with dynamic data


To start your Phoenix server:

  * Run `mix setup` to install and setup dependencies
  * Start Phoenix endpoint with `mix phx.server` or inside IEx with `iex -S mix phx.server`

Now you can visit [`localhost:4000`](http://localhost:4000) from your browser.

Ready to run in production? Please [check our deployment guides](https://hexdocs.pm/phoenix/deployment.html).



## Learn more

  * Official website: https://www.phoenixframework.org/
  * Guides: https://hexdocs.pm/phoenix/overview.html
  * Docs: https://hexdocs.pm/phoenix
  * Forum: https://elixirforum.com/c/phoenix-forum
  * Source: https://github.com/phoenixframework/phoenix

