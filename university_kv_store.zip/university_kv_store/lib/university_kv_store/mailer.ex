defmodule UniversityKvStore.Mailer do
  use Swoosh.Mailer, otp_app: :university_kv_store
end
