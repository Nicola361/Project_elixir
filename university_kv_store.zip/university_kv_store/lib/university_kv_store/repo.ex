defmodule UniversityKvStore.Repo do
  use Ecto.Repo,
    otp_app: :university_kv_store,
    adapter: Ecto.Adapters.Postgres
end
