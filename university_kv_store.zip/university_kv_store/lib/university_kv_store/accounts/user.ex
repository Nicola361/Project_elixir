defmodule UniversityKvStore.Accounts.User do
  use Ecto.Schema
  import Ecto.Changeset

  @primary_key {:id, :id, autogenerate: true}

  schema "users" do
    field :address, :string
    field :first_name, :string
    field :last_name, :string
    field :email, :string
    field :gender, :string
    field :date_of_birth, :date
    field :phone, :string
    field :about, :string

    timestamps(type: :utc_datetime)
  end

  @doc false
  def changeset(user, attrs) do
    user
    |> cast(attrs, [:first_name, :last_name, :email, :date_of_birth, :phone, :address, :about, :gender])
    |> validate_required([:first_name, :last_name, :email, :date_of_birth])
    |> unique_constraint(:email, name: :users_email_index) # Match the unique index name
  end
end
