defmodule UniversityKvStore.Repo.Migrations.CreateUsers do
  use Ecto.Migration

  def change do
    create table(:users, primary_key: false) do
      add :id, :bigserial, primary_key: true
      add :first_name, :string
      add :last_name, :string
      add :email, :string
      add :date_of_birth, :date
      add :phone, :string
      add :gender, :string
      add :address, :string
      add :about, :text

      timestamps(type: :utc_datetime)
    end

    create index(:users, [:first_name])
    create index(:users, [:last_name])
    create index(:users, [:phone])
    create unique_index(:users, [:email])
  end
end
