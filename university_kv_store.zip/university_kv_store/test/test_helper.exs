ExUnit.start()
Faker.start()
Ecto.Adapters.SQL.Sandbox.mode(UniversityKvStore.Repo, :manual)
