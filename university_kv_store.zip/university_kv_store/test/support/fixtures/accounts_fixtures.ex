defmodule UniversityKvStore.AccountsFixtures do
  @moduledoc """
  This module defines test helpers for creating
  entities via the `UniversityKvStore.Accounts` context.
  """

  @doc """
  Generate a user.
  """
  def user_fixture(attrs \\ %{}) do
    {:ok, user} =
      attrs
      |> Enum.into(%{
        about: Faker.Person.title(),
        address: Faker.Address.street_address(true),
        date_of_birth: Faker.Date.date_of_birth(18..80),
        email: Faker.Internet.email(),
        first_name: Faker.Person.first_name(),
        last_name: Faker.Person.last_name(),
        phone: Faker.Phone.PtBr.phone(),
        gender: Enum.random(["male", "female", "others"])
      })
      |> UniversityKvStore.Accounts.create_user()

    user
  end
end
