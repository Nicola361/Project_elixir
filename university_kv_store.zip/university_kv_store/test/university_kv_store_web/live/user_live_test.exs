defmodule UniversityKvStoreWeb.UserLiveTest do
  use UniversityKvStoreWeb.ConnCase

  import Phoenix.LiveViewTest
  import UniversityKvStore.AccountsFixtures

  @create_attrs %{address: Faker.Address.street_address(true), first_name: Faker.Person.first_name(), last_name: Faker.Person.last_name(), email: Faker.Internet.email(), date_of_birth: Faker.Date.date_of_birth(18..80), phone: Faker.Phone.PtBr.phone(), about: Faker.Person.title(), gender: Enum.random(["male", "female", "others"])}
  @update_attrs %{address: Faker.Address.street_address(true), first_name: Faker.Person.first_name(), last_name: Faker.Person.last_name(), email: Faker.Internet.email(), date_of_birth: Faker.Date.date_of_birth(18..80), phone: Faker.Phone.PtBr.phone(), about: Faker.Person.title(), gender: Enum.random(["male", "female", "others"])}
  @invalid_attrs %{address: nil, first_name: nil, last_name: nil, email: nil, date_of_birth: nil, phone: nil, about: nil}

  defp create_user(_) do
    user = user_fixture()
    %{user: user}
  end

  describe "Index" do
    setup [:create_user]

    test "lists all users", %{conn: conn, user: user} do
      {:ok, _index_live, html} = live(conn, ~p"/users")

      assert html =~ "Listing Students"
      assert html =~ user.address
    end

    test "saves new user", %{conn: conn} do
      {:ok, index_live, _html} = live(conn, ~p"/users")

      assert index_live |> element("a", "New Student") |> render_click() =~
               "New Student"

      assert_patch(index_live, ~p"/users/new")

      assert index_live
             |> form("#student-form", user: @invalid_attrs)
             |> render_change() =~ "can&#39;t be blank"

      assert index_live
             |> form("#student-form", user: @create_attrs)
             |> render_submit()

      assert_patch(index_live, ~p"/users")

      html = render(index_live)
      assert html =~ "Student created successfully"
      assert html =~ @create_attrs.address
    end

    test "updates user in listing", %{conn: conn, user: user} do
      {:ok, index_live, _html} = live(conn, ~p"/users")

      assert index_live |> element("#users-#{user.id} a", "Edit") |> render_click() =~
               "Edit Student"

      assert_patch(index_live, ~p"/users/#{user}/edit")

      assert index_live
             |> form("#student-form", user: @invalid_attrs)
             |> render_change() =~ "can&#39;t be blank"

      assert index_live
             |> form("#student-form", user: @update_attrs)
             |> render_submit()

      assert_patch(index_live, ~p"/users")

      html = render(index_live)
      assert html =~ "Student updated successfully"
      assert html =~ @update_attrs.address
    end

    test "deletes user in listing", %{conn: conn, user: user} do
      {:ok, index_live, _html} = live(conn, ~p"/users")

      assert index_live |> element("#users-#{user.id} a", "Delete") |> render_click()
      refute has_element?(index_live, "#users-#{user.id}")
    end
  end

  describe "Show" do
    setup [:create_user]

    test "displays user", %{conn: conn, user: user} do
      {:ok, _show_live, html} = live(conn, ~p"/users/#{user}")

      assert html =~ "Show Student"
      assert html =~ user.address
    end

    test "updates user within modal", %{conn: conn, user: user} do
      {:ok, show_live, _html} = live(conn, ~p"/users/#{user}")

      assert show_live |> element("a", "Edit") |> render_click() =~
               "Edit Student"

      assert_patch(show_live, ~p"/users/#{user}/show/edit")

      assert show_live
             |> form("#student-form", user: @invalid_attrs)
             |> render_change() =~ "can&#39;t be blank"

      assert show_live
             |> form("#student-form", user: @update_attrs)
             |> render_submit()

      assert_patch(show_live, ~p"/users/#{user}")

      html = render(show_live)
      assert html =~ "Student updated successfully"
      assert html =~ @update_attrs.address
    end
  end
end
